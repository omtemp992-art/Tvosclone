#!/usr/bin/env python3
"""Deploy AppleTVOS Launcher to a Sony Bravia over ADB. Dry-run by default for anything destructive."""
import argparse, subprocess, sys

PKG = "com.appletvos.launcher"
ACTIVITY = f"{PKG}/.ui.MainActivity"
# Candidates only. Names are NOT verified for your firmware: the script touches a package only if
# `pm list packages` shows it, and only with --apply. Disabled (reversible), never uninstalled.
CANDIDATES = [
    "com.google.android.tvrecommendations",
    "com.sony.tv.customrecommendations",
    "com.google.android.feedback",
]

def adb(serial, *args, check=True):
    r = subprocess.run(["adb", "-s", serial, *args], capture_output=True, text=True, timeout=180)
    out = (r.stdout + r.stderr).strip()
    print(f"$ adb {' '.join(args)}\n{out}" if out else f"$ adb {' '.join(args)}")
    if check and r.returncode != 0:
        sys.exit(f"[!] failed: adb {' '.join(args)}")
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ip"); ap.add_argument("--apk", default="app-release.apk")
    ap.add_argument("--debloat", action="store_true", help="also disable candidate packages")
    ap.add_argument("--apply", action="store_true", help="actually disable (otherwise dry-run)")
    ap.add_argument("--anim", type=float, help="animation scale, e.g. 0.5")
    a = ap.parse_args()

    serial = a.ip if ":" in a.ip else f"{a.ip}:5555"
    out = subprocess.run(["adb", "connect", serial], capture_output=True, text=True).stdout
    print(out.strip())
    if "connected" not in out:  # adb connect exits 0 even on failure
        sys.exit("[!] Could not connect. Enable network debugging and accept the RSA prompt on the TV.")

    print("Model:", adb(serial, "shell", "getprop", "ro.product.model"),
          "| SDK:", adb(serial, "shell", "getprop", "ro.build.version.sdk"))

    adb(serial, "install", "-r", a.apk)
    adb(serial, "shell", "cmd", "package", "set-home-activity", ACTIVITY, check=False)

    rollback = ["#!/bin/bash", f"# Restores stock behaviour for {serial}",
                f"adb -s {serial} uninstall {PKG}"]
    if a.debloat:
        installed = {l.split(":", 1)[1] for l in adb(serial, "shell", "pm", "list", "packages").splitlines() if l.startswith("package:")}
        for pkg in CANDIDATES:
            if pkg not in installed:
                print(f"[skip] {pkg} not present"); continue
            rollback.append(f"adb -s {serial} shell pm enable {pkg}")
            if a.apply:
                adb(serial, "shell", "pm", "disable-user", "--user", "0", pkg, check=False)
            else:
                print(f"[dry-run] would disable {pkg}")
        open("restore_stock.sh", "w").write("\n".join(rollback) + "\n")
        print("[+] wrote restore_stock.sh")

    if a.anim:
        for k in ("window_animation_scale", "transition_animation_scale", "animator_duration_scale"):
            adb(serial, "shell", "settings", "put", "global", k, str(a.anim))

    adb(serial, "shell", "input", "keyevent", "KEYCODE_HOME", check=False)

if __name__ == "__main__":
    main()
