package com.appletvos.launcher.ui

import android.content.Intent

data class AppEntry(val packageName: String, val label: String, val launchIntent: Intent)
