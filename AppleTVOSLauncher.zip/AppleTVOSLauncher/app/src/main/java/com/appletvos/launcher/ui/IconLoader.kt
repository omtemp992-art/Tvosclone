package com.appletvos.launcher.ui

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Renders every app to a fixed 320x180 bitmap and keeps at most ~6 MB of them. */
class IconLoader(private val pm: PackageManager) {

    private val cache = object : LruCache<String, Bitmap>(6 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun peek(pkg: String): Bitmap? = cache.get(pkg)
    fun clear() = cache.evictAll()

    suspend fun get(e: AppEntry): Bitmap =
        peek(e.packageName) ?: withContext(Dispatchers.IO) { render(e).also { cache.put(e.packageName, it) } }

    private fun render(e: AppEntry): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val banner: Drawable? = try { pm.getActivityBanner(e.launchIntent) } catch (_: Exception) { null }
        if (banner != null) {
            banner.setBounds(0, 0, W, H)
            banner.draw(canvas)
        } else {
            canvas.drawColor(0xFF26262B.toInt())
            val icon = try { pm.getActivityIcon(e.launchIntent) } catch (_: Exception) { pm.defaultActivityIcon }
            val s = 110
            icon.setBounds((W - s) / 2, (H - s) / 2, (W + s) / 2, (H + s) / 2)
            icon.draw(canvas)
        }
        return bmp
    }

    private companion object { const val W = 320; const val H = 180 }
}
