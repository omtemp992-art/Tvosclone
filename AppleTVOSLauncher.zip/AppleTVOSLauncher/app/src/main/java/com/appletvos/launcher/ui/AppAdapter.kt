package com.appletvos.launcher.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.appletvos.launcher.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class AppAdapter(
    private val scope: CoroutineScope,
    private val icons: IconLoader,
    private val onClick: (AppEntry) -> Unit,
    private val onFocus: (AppEntry) -> Unit
) : ListAdapter<AppEntry, AppAdapter.VH>(Diff) {

    object Diff : DiffUtil.ItemCallback<AppEntry>() {
        override fun areItemsTheSame(a: AppEntry, b: AppEntry) = a.packageName == b.packageName
        override fun areContentsTheSame(a: AppEntry, b: AppEntry) = a.label == b.label
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.ivIcon)
        var job: Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        v.clipToOutline = true
        val vh = VH(v)
        v.setOnFocusChangeListener { view, focused ->
            FocusAnimator.apply(view, focused)
            if (focused) vh.bindingAdapterPosition.takeIf { it != RecyclerView.NO_POSITION }?.let { onFocus(getItem(it)) }
        }
        v.setOnClickListener {
            vh.bindingAdapterPosition.takeIf { it != RecyclerView.NO_POSITION }?.let { onClick(getItem(it)) }
        }
        return vh
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val e = getItem(position)
        h.job?.cancel()
        val cached = icons.peek(e.packageName)
        if (cached != null) { h.img.setImageBitmap(cached); return }
        h.img.setImageDrawable(null)
        h.job = scope.launch { h.img.setImageBitmap(icons.get(e)) }
    }

    override fun onViewRecycled(h: VH) {
        h.job?.cancel(); h.job = null
        h.img.setImageDrawable(null)
        h.itemView.animate().cancel()
        h.itemView.scaleX = 1f; h.itemView.scaleY = 1f; h.itemView.translationZ = 0f
    }
}
