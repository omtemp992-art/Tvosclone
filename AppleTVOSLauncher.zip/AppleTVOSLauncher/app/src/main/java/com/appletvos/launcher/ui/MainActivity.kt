package com.appletvos.launcher.ui

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.net.Network
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.format.DateFormat
import android.view.KeyEvent
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.leanback.widget.BaseGridView
import androidx.leanback.widget.HorizontalGridView
import androidx.leanback.widget.VerticalGridView
import androidx.lifecycle.lifecycleScope
import com.appletvos.launcher.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var repo: AppRepository
    private lateinit var icons: IconLoader
    private lateinit var tvClock: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvTitle: TextView
    private lateinit var btnInputs: Button
    private lateinit var btnNetwork: Button
    private lateinit var dockContainer: android.view.View
    private lateinit var dock: HorizontalGridView
    private lateinit var grid: VerticalGridView
    private lateinit var dockAdapter: AppAdapter
    private lateinit var gridAdapter: AppAdapter

    private val main = Handler(Looper.getMainLooper())
    private val dateFmt = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault())
    private var expanded = false
    private var inputIndex = 0
    private var refreshJob: Job? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var receiversRegistered = false

    private val refreshRunnable = Runnable { refreshApps() }

    private val clockReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = updateClock()
    }
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            main.removeCallbacks(refreshRunnable)
            main.postDelayed(refreshRunnable, 500) // debounce install bursts
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repo = AppRepository(packageManager, packageName)
        icons = IconLoader(packageManager)

        tvClock = findViewById(R.id.tvClock)
        tvDate = findViewById(R.id.tvDate)
        tvTitle = findViewById(R.id.tvAppTitleIndicator)
        btnInputs = findViewById(R.id.btnInputs)
        btnNetwork = findViewById(R.id.btnNetwork)
        dockContainer = findViewById(R.id.dockContainer)
        dock = findViewById(R.id.rvAppDock)
        grid = findViewById(R.id.rvExpandedGrid)

        val onFocus = { e: AppEntry -> tvTitle.text = e.label }
        dockAdapter = AppAdapter(lifecycleScope, icons, ::launchApp, onFocus)
        gridAdapter = AppAdapter(lifecycleScope, icons, ::launchApp, onFocus)

        dock.adapter = dockAdapter
        dock.setItemSpacing(dp(24))
        dock.windowAlignment = BaseGridView.WINDOW_ALIGN_NO_EDGE
        dock.windowAlignmentOffsetPercent = 50f
        dock.itemAlignmentOffsetPercent = 50f
        dock.setHasFixedSize(true)
        dock.setOnKeyInterceptListener { e ->
            if (e.action == KeyEvent.ACTION_DOWN && e.keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                if (gridAdapter.itemCount > 0) expand()
                true
            } else false
        }

        grid.adapter = gridAdapter
        grid.setNumColumns(COLS) // 960dp - 96dp padding, 5 cols, 16dp gaps = exactly 160dp per column
        grid.setItemSpacing(dp(16))
        grid.setHasFixedSize(true)
        grid.setOnKeyInterceptListener { e ->
            if (e.action == KeyEvent.ACTION_DOWN && e.keyCode == KeyEvent.KEYCODE_DPAD_UP && grid.selectedPosition < COLS) {
                collapse(); true
            } else false
        }

        btnInputs.setOnClickListener { switchInput() }
        btnNetwork.setOnClickListener { safeStart(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        findViewById<android.view.View>(R.id.btnSettings).setOnClickListener { safeStart(Intent(Settings.ACTION_SETTINGS)) }

        // A launcher must never finish() on Back.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (expanded) collapse() else dock.requestFocus() }
        })

        updateClock()
    }

    override fun onStart() {
        super.onStart()
        registerReceivers()
        registerNetwork()
        updateClock()
        refreshApps()
    }

    override fun onStop() {
        main.removeCallbacksAndMessages(null)
        unregisterReceivers()
        unregisterNetwork()
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) { // Home pressed while we are already on top
        super.onNewIntent(intent)
        if (expanded) collapse()
        dock.scrollToPosition(0)
        dock.requestFocus()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW) icons.clear()
    }

    private fun refreshApps() {
        refreshJob?.cancel()
        refreshJob = lifecycleScope.launch {
            val all = withContext(Dispatchers.Default) { repo.load() }
            val pinned = PINNED.mapNotNull { p -> all.firstOrNull { it.packageName == p } }
            val dockList = (pinned + all.filter { it !in pinned }).take(DOCK_MAX)
            dockAdapter.submitList(dockList)
            gridAdapter.submitList(all)
            if (dock.hasFocus().not() && !expanded) dock.requestFocus()
        }
    }

    private fun expand() {
        expanded = true
        grid.visibility = android.view.View.VISIBLE
        dockContainer.animate().translationY(-dp(100).toFloat()).setDuration(200).start()
        grid.post { grid.selectedPosition = 0; grid.requestFocus() }
    }

    private fun collapse() {
        expanded = false
        dock.requestFocus()
        grid.visibility = android.view.View.GONE
        dockContainer.animate().translationY(0f).setDuration(200).start()
    }

    private fun launchApp(e: AppEntry) {
        try { startActivity(e.launchIntent) }
        catch (_: ActivityNotFoundException) { refreshApps() }
        catch (_: SecurityException) { refreshApps() }
    }

    private fun switchInput() {
        val tm = getSystemService(TvInputManager::class.java) ?: return
        val inputs = tm.tvInputList.filter { it.isPassthroughInput }
        if (inputs.isEmpty()) { Toast.makeText(this, "No external inputs", Toast.LENGTH_SHORT).show(); return }
        val info = inputs[inputIndex++ % inputs.size]
        btnInputs.text = info.loadLabel(this)
        safeStart(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(info.id)))
    }

    private fun safeStart(i: Intent) {
        try { startActivity(i) } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
        }
    }

    private fun updateClock() {
        val now = Date()
        tvClock.text = DateFormat.getTimeFormat(this).format(now)
        tvDate.text = dateFmt.format(now)
    }

    private fun registerReceivers() {
        if (receiversRegistered) return
        registerReceiver(clockReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK); addAction(Intent.ACTION_TIME_CHANGED); addAction(Intent.ACTION_TIMEZONE_CHANGED)
        })
        registerReceiver(packageReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        })
        receiversRegistered = true
    }

    private fun unregisterReceivers() {
        if (!receiversRegistered) return
        unregisterReceiver(clockReceiver); unregisterReceiver(packageReceiver)
        receiversRegistered = false
    }

    private fun registerNetwork() {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        btnNetwork.text = if (cm.activeNetwork != null) "Online" else "Offline"
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(n: Network) { main.post { btnNetwork.text = "Online" } }
            override fun onLost(n: Network) { main.post { btnNetwork.text = "Offline" } }
        }
        try { cm.registerDefaultNetworkCallback(cb); netCallback = cb } catch (_: Exception) {}
    }

    private fun unregisterNetwork() {
        val cb = netCallback ?: return
        try { getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(cb) } catch (_: IllegalArgumentException) {}
        netCallback = null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private companion object {
        const val COLS = 5
        const val DOCK_MAX = 10
        val PINNED = listOf(
            "com.netflix.ninja", "com.google.android.youtube.tv", "com.amazon.amazonvideo.livingroom",
            "com.disney.disneyplus", "com.android.tv.settings"
        )
    }
}
