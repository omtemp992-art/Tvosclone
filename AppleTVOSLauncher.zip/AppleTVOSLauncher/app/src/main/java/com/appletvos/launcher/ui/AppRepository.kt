package com.appletvos.launcher.ui

import android.content.Intent
import android.content.pm.PackageManager

class AppRepository(private val pm: PackageManager, private val selfPackage: String) {

    /** Blocking; call from a background dispatcher. Leanback activities win over plain LAUNCHER ones. */
    fun load(): List<AppEntry> {
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        for (category in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == selfPackage || !seen.add(pkg)) continue
                val launch = Intent(Intent.ACTION_MAIN).addCategory(category)
                    .setClassName(pkg, ri.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                out += AppEntry(pkg, ri.loadLabel(pm).toString(), launch)
            }
        }
        return out.sortedBy { it.label.lowercase() }
    }
}
