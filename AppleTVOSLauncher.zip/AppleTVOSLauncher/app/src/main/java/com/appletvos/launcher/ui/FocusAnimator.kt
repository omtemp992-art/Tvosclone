package com.appletvos.launcher.ui

import android.view.View
import android.view.animation.DecelerateInterpolator

object FocusAnimator {
    private val interpolator = DecelerateInterpolator()

    /** ViewPropertyAnimator: no allocations per call, and a new focus change replaces the running one. */
    fun apply(view: View, focused: Boolean) {
        val scale = if (focused) 1.15f else 1f
        val z = if (focused) 16f * view.resources.displayMetrics.density else 0f
        view.animate().cancel()
        view.animate().scaleX(scale).scaleY(scale).translationZ(z)
            .setDuration(150).setInterpolator(interpolator).start()
    }
}
